//Bring in unit testing code and tell it to build a main function
#define DOCTEST_CONFIG_IMPLEMENT_WITH_MAIN
//This pragma supresses a bunch of warnings QTCreator produces (and should not)
#pragma clang diagnostic ignored "-Woverloaded-shift-op-parentheses"
#include "doctest.h"

//Use Approx from doctest without saying doctest::Approx
using doctest::Approx;

//Include your .h files
#include "Pin.h"
#include "NotGate.h"
#include "TwoInputGate.h"

#include <iostream>
#include <vector>

using namespace std;


TEST_CASE( "Components/Pin" ) {
    cout << "Pin Only Test..." << endl;    

    Pin a("A");
    a.setValue(false);

    REQUIRE(a.getOutput() == false);

    a.setValue(true);
    REQUIRE(a.getOutput() == true);
}

