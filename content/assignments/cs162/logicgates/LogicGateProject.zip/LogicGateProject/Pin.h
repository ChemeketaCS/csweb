#ifndef PIN_H
#define PIN_H

#include "Component.h"


#endif // PIN_H
