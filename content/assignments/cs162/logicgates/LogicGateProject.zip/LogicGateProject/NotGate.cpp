#include "NotGate.h"
