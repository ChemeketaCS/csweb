#ifndef NOTGATE_H
#define NOTGATE_H

#include <memory>
#include "Component.h"



#endif // NOTGATE_H
