#ifndef TWOINPUTGATE_H
#define TWOINPUTGATE_H

#include <memory>
#include "Component.h"

//Supported operations
enum LogicOperation {OR, AND, XOR};

//Lookup table for names of operations:
//  LOGIC_LABELS[OR] --> "OR"
//  LOGIC_LABELS[AND] --> "AND"...
const std::string LOGIC_LABELS[] = {"OR", "AND", "XOR"};





#endif // TWOINPUTGATE_H
