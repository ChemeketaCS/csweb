#include "TwoInputGate.h"
