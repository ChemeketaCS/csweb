#ifndef COMPONENT_H
#define COMPONENT_H

#include <string>



#endif // COMPONENT_H
